Django-Related-DropDowns
========================

2 synced drop downs



you select country , i'll select related cities using ajax :) 

![alt tag](https://github.com/nodet07/Django-Related-DropDowns/blob/master/iran.png)
![alt tag](https://github.com/nodet07/Django-Related-DropDowns/blob/master/USA.png)
