from django.contrib import admin
from map.models import City, Country


admin.site.register(Country)
admin.site.register(City)
